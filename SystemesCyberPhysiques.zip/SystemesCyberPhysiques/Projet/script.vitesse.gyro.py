
import pandas as pd
import matplotlib.pyplot as plt
import sys
from pathlib import Path

# ==================================================
# 1. Chemin du fichier
# ==================================================

fichier = (
    Path(sys.argv[1])
    if len(sys.argv) > 1
    else Path("Data") / "Vitesses" / "gyro.txt"
)

if not fichier.exists():
    raise FileNotFoundError(
        f"Fichier introuvable : {fichier.resolve()}"
    )

# ==================================================
# 2. Lecture des mesures
# ==================================================

df = pd.read_csv(
    fichier,
    sep=r"\s+",
    engine="python"
)

df = df.iloc[:, :2].copy()
df.columns = ["Puissance", "Vitesse"]

df["Puissance"] = pd.to_numeric(
    df["Puissance"], errors="coerce"
)
df["Vitesse"] = pd.to_numeric(
    df["Vitesse"], errors="coerce"
)

df = df.dropna(subset=["Puissance", "Vitesse"])

if df.empty:
    raise ValueError("Aucune mesure numérique valide.")

# ==================================================
# 3. Préparation des données
# ==================================================

puissance = df["Puissance"]

# On utilise la valeur absolue de la vitesse
vitesse = df["Vitesse"].abs()

# Minimum et maximum
idx_min = vitesse.idxmin()
idx_max = vitesse.idxmax()

p_min = puissance.loc[idx_min]
v_min = vitesse.loc[idx_min]

p_max = puissance.loc[idx_max]
v_max = vitesse.loc[idx_max]

# ==================================================
# 4. Tracé de la courbe
# ==================================================

plt.figure(figsize=(11, 6))

plt.plot(
    puissance,
    vitesse,
    color="blue",
    linewidth=2,
    label="Vitesse absolue mesurée"
)

plt.scatter(
    p_min,
    v_min,
    color="red",
    s=80,
    zorder=5,
    label=f"Minimum : {v_min:g} RPM (puissance = {p_min:g})"
)

plt.scatter(
    p_max,
    v_max,
    color="green",
    s=80,
    zorder=5,
    label=f"Maximum : {v_max:g} RPM (puissance = {p_max:g})"
)

plt.title("Vitesse du moteur EV3 en fonction de la puissance")
plt.xlabel("Puissance du moteur")
plt.ylabel("Vitesse absolue (RPM)")

plt.grid(True, linestyle="--", alpha=0.4)
plt.legend()
plt.tight_layout()

# ==================================================
# 5. Sauvegarde et affichage
# ==================================================

sortie = fichier.parent / "graphique_moteur.png"

plt.savefig(sortie, dpi=160, bbox_inches="tight")

print(f"Minimum : {v_min:g} RPM pour une puissance de {p_min:g}")
print(f"Maximum : {v_max:g} RPM pour une puissance de {p_max:g}")
print(f"Graphique enregistré : {sortie.resolve()}")

plt.show()
