
#pragma config(Sensor, S1,     SensorTouch1, sensorEV3_Touch)
#pragma config(Sensor, S4,     SensorGyro4,  sensorEV3_Gyro)
#pragma config(Motor,  motorA, A_moteur,     tmotorEV3_Large, PIDControl, encoder)

#define TACHE_ACTIVE       1

#define SCREEN_HEIGHT      120
#define SCREEN_WIDTH       180

// Vitesse utilis�e pour atteindre la consigne
#define PUISSANCE_MOTEUR   20

#define MIN_POWER  5
#define MAX_SPEED  143

#define PENTE2 1.71

#define PENTE 1.7176

int consigne = 0;

// Position r�elle du moteur
int position_reelle = 0;

// Erreur entre la consigne et la position r�elle
int erreur = 0;

// Correction actuellement calcul�e
int correction = 0;

int erreurs[10];
int i_erreur = 0;


// ============================================================================
// S�MAPHORE
// ============================================================================

// Prot�ge les variables partag�es entre les diff�rentes t�ches.
TSemaphore capMotorMutex;

void launchMotorSpeed(int speed)
{
    if(speed > MAX_SPEED)
        speed = MAX_SPEED;

    if(speed < -MAX_SPEED)
        speed = -MAX_SPEED;

    if(fabs(speed) < MIN_POWER)
        speed = 0;

    setMotorSpeed(motorA, speed / PENTE);
}

void modifierLaConsigne(int delta)
{
    semaphoreLock(capMotorMutex);

    consigne = consigne + delta;

    semaphoreUnlock(capMotorMutex);
}

void ajouterErreur(int erreur){
		erreurs[i_erreur] = erreur;
		i_erreur = (i_erreur + 1) % 10 ;
}

void resetErreurs()
{
	for (int i = 0; i < 10; i++)
  {
 			erreurs[i] = 0;
  }

}

float Kp = 0.1;
float Ki = 0.1;
float Kd = 0.1;

task keepHeadingPID()
{
    int consigne_locale;
    int position_locale;

    int erreur_locale;
    int erreur_precedente = 0;

    int derivee;
    int correction_locale;

    int sum_erreur;


    while(TACHE_ACTIVE)
    {
        semaphoreLock(capMotorMutex);

        consigne_locale = consigne;

        semaphoreUnlock(capMotorMutex);

        position_locale = getMotorEncoder(motorA);

        erreur_locale = consigne_locale - position_locale;

        ajouterErreur(erreur_locale);

        sum_erreur = 0;

        for(int i = 0; i < 10; i++)
        {
            sum_erreur += erreurs[i];
        }

        derivee = erreur_locale - erreur_precedente;

        correction_locale =
              Kp * erreur_locale
            + Ki * sum_erreur
            + Kd * derivee;

        erreur_precedente = erreur_locale;

        if(abs(erreur_locale) <= 2)
        {
            correction_locale = 0;
        }

        semaphoreLock(capMotorMutex);

        position_reelle = position_locale;
        erreur = erreur_locale;
        correction = correction_locale;

        semaphoreUnlock(capMotorMutex);


        if(correction_locale == 0)
        {
            setMotorSpeed(motorA, 0);
        }
        else
        {
            launchMotorSpeed(correction_locale);
        }

        delay(30);
    }
}

task IHM()
{
    int consigne_locale;
    int position_locale;
    int erreur_locale;
    int correction_locale;

    while (TACHE_ACTIVE)
    {

        semaphoreLock(capMotorMutex);

        consigne_locale = consigne;
        position_locale = position_reelle;
        erreur_locale = erreur;
        correction_locale = correction;

        semaphoreUnlock(capMotorMutex);


        eraseDisplay();

        displayBigStringAt( 0,   10,  "POSITION : %d",   position_locale );

				displayBigStringAt( 0, 35, "ERREUR   : %d", erreur_locale  );

        displayBigStringAt(
            0,
            60,
            "CORRECT. : %d",
            correction_locale
        );

        displayBigStringAt(
            0,
            85,
            "CONSIGNE : %d",
            consigne_locale
        );


    }
}

task watchButtons()
{
    while (getButtonPress(buttonEnter) == 0)
    {
        if (getButtonPress(buttonUp) == 1)
        {
            modifierLaConsigne(90);

            // Attendre le rel�chement du bouton
            while (getButtonPress(buttonUp) == 1)
            {
            }
        }
        else if (getButtonPress(buttonDown) == 1)
        {
            modifierLaConsigne(-90);

            while (getButtonPress(buttonDown) == 1)
            {
            }
        }
        else if (getButtonPress(buttonLeft) == 1)
        {
            modifierLaConsigne(-10);

            while (getButtonPress(buttonLeft) == 1)
            {
            }
        }

        else if (getButtonPress(buttonRight) == 1)
        {
            modifierLaConsigne(10);

            while (getButtonPress(buttonRight) == 1)
            {
            }
        }
    }
}



task main()
{
    semaphoreInitialize(capMotorMutex);
    resetMotorEncoder(motorA);

    semaphoreLock(capMotorMutex);

    consigne = 0;
    position_reelle = 0;
    erreur = 0;
    correction = 0;

    semaphoreUnlock(capMotorMutex);

    resetErreurs();

    startTask(keepHeadingPID);

    startTask(IHM);

    startTask(watchButtons);



    while (TACHE_ACTIVE){}
}
