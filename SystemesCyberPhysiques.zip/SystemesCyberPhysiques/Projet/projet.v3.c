
#pragma config(Sensor, S1,     SensorTouch1, sensorEV3_Touch)
#pragma config(Sensor, S4,     SensorGyro4,  sensorEV3_Gyro)
#pragma config(Motor,  motorA, A_moteur,     tmotorEV3_Large, PIDControl, encoder)

#define TACHE_ACTIVE       1

#define SCREEN_HEIGHT      120
#define SCREEN_WIDTH       180

// Vitesse utilis�e pour atteindre la consigne
#define PUISSANCE_MOTEUR   20

int consigne = 0;

// Position r�elle du moteur
int position_reelle = 0;

// Erreur entre la consigne et la position r�elle
int erreur = 0;

// Correction actuellement calcul�e
int correction = 0;


// ============================================================================
// S�MAPHORE
// ============================================================================

// Prot�ge les variables partag�es entre les diff�rentes t�ches.
TSemaphore capMotorMutex;


// ============================================================================
// MODIFICATION DE LA CONSIGNE
// ============================================================================

void modifierLaConsigne(int delta)
{
    semaphoreLock(capMotorMutex);

    consigne = consigne + delta;

    semaphoreUnlock(capMotorMutex);
}

task keepHeading()
{
    int consigne_locale;
    int ancienne_consigne = 0;

    int position_locale;
    int erreur_locale;

    while (TACHE_ACTIVE)
    {
        semaphoreLock(capMotorMutex);

        consigne_locale = consigne;

        semaphoreUnlock(capMotorMutex);

        position_locale = getMotorEncoder(motorA);

        erreur_locale = consigne_locale - position_locale;


        semaphoreLock(capMotorMutex);

        position_reelle = position_locale;
        erreur = erreur_locale;
        correction = erreur_locale;

        semaphoreUnlock(capMotorMutex);

        if (consigne_locale != ancienne_consigne)
        {
            setMotorTarget(
                motorA,
                consigne_locale,
                PUISSANCE_MOTEUR
            );

            ancienne_consigne = consigne_locale;
        }


        // P�riode de keepHeading
        delay(50);
    }
}

task IHM()
{
    int consigne_locale;
    int position_locale;
    int erreur_locale;
    int correction_locale;

    while (TACHE_ACTIVE)
    {

        semaphoreLock(capMotorMutex);

        consigne_locale = consigne;
        position_locale = position_reelle;
        erreur_locale = erreur;
        correction_locale = correction;

        semaphoreUnlock(capMotorMutex);


        eraseDisplay();

        displayBigStringAt(
            0,
            10,
            "POSITION : %d",
            position_locale
        );

        displayBigStringAt(
            0,
            35,
            "ERREUR   : %d",
            erreur_locale
        );

        displayBigStringAt(
            0,
            60,
            "CORRECT. : %d",
            correction_locale
        );

        displayBigStringAt(
            0,
            85,
            "CONSIGNE : %d",
            consigne_locale
        );


    }
}

task watchButtons()
{
    while (getButtonPress(buttonEnter) == 0)
    {

        if (getButtonPress(buttonUp) == 1)
        {
            modifierLaConsigne(90);

            // Attendre le rel�chement du bouton
            while (getButtonPress(buttonUp) == 1)
            {
            }
        }

        else if (getButtonPress(buttonDown) == 1)
        {
            modifierLaConsigne(-90);

            while (getButtonPress(buttonDown) == 1)
            {
            }
        }

        else if (getButtonPress(buttonLeft) == 1)
        {
            modifierLaConsigne(-10);

            while (getButtonPress(buttonLeft) == 1)
            {
            }
        }


        else if (getButtonPress(buttonRight) == 1)
        {
            modifierLaConsigne(10);

            while (getButtonPress(buttonRight) == 1)
            {
            }
        }


    }
}



task main()
{

    semaphoreInitialize(capMotorMutex);



    resetMotorEncoder(motorA);


    semaphoreLock(capMotorMutex);

    consigne = 0;
    position_reelle = 0;
    erreur = 0;
    correction = 0;

    semaphoreUnlock(capMotorMutex);



    startTask(keepHeading);

    startTask(IHM);

    startTask(watchButtons);



    while (TACHE_ACTIVE)
    {

    }
}
