#pragma config(Sensor, S1,     SensorTouch1, sensorEV3_Touch)
#pragma config(Sensor, S4,     SensorGyro4,  sensorEV3_Gyro)
#pragma config(Motor,  motorA, A_moteur,     tmotorEV3_Large, PIDControl, encoder)

float vitesses[100]; // Tableau stockant les vitesses angulaires mesurées par le gyromètre

void gyroRateCharacterization()
{
    string filename = "gyro.txt";
    long fileHandle = fileOpenWrite(filename);
    string puis;
    int puissance;
    int vitesse;
    int positionDepart;

    // Réinitialisation du gyromètre avant le début des mesures
    resetGyro(SensorGyro4);

    stringFormat(puis, "Puissance\tVitesse\n");
    fileWriteData(fileHandle, puis, strlen(puis));

    // Balayage des puissances de 0 à 99 % avec retour à la position initiale à chaque itération
    for (puissance = 0; puissance < 100; puissance++)
    {
        // 1. Mémoriser la position angulaire de départ pour éviter l'enroulement du câble
        positionDepart = nMotorEncoder[motorA];

        // 2. Appliquer la puissance dans le sens positif
        setMotorSpeed(motorA, puissance);

        // 3. Laisser le moteur atteindre son régime établi pendant 500 ms
        wait1Msec(500);

        // 4. Lire la vitesse de rotation (en deg/s) délivrée par le gyromètre
        vitesse = fabs(getGyroRate(SensorGyro4));
        vitesses[puissance] = vitesse;

        // 5. Arrêter complètement le moteur avant d'inverser le sens
        setMotorSpeed(motorA, 0);
        waitUntilMotorStop(motorA);

        // 6. Ramener l'axe à sa position initiale pour détordre le câble
        setMotorTarget(motorA, positionDepart, 50);
        waitUntilMotorStop(motorA);

        // 7. Enregistrer la mesure dans le fichier texte
        stringFormat(puis, "%d\t%d\n", puissance, vitesse);
        fileWriteData(fileHandle, puis, strlen(puis));
    }

    fileClose(fileHandle);
    stopAllTasks();
}