#pragma config(Sensor, S1,     SensorTouch1,   sensorEV3_Touch)
#pragma config(Sensor, S4,     SensorGyro4,    sensorEV3_Gyro)
#pragma config(Motor,  motorA, A_moteur,       tmotorEV3_Large, PIDControl, encoder)

int puissances[100]; // Tableau stockant les vitesses relevées pour chaque puissance

void motorCharacterization()
{
    int sens = 1;
    int puissance = 0;
    int active = 0;

    // Ouverture du fichier de sortie sur la brique EV3 pour l'export des données
    string filename = "temp.txt";
    long fileHandle = fileOpenWrite(filename);
    string puis = "puissance rpm \n";
    fileWriteData(fileHandle, puis, strlen(puis));

    // Balayage des puissances de 0 à 100 % (interruption possible via le bouton central)
    while (getButtonPress(buttonEnter) == 0 && !active)
    {
        // Lecture de la vitesse instantanée de rotation via l'encodeur optique (en RPM)
        puissances[puissance] = getMotorRPM(A_moteur);

        // Formatage et écriture du couple (puissance, vitesse) dans le fichier
        stringFormat(puis, "\n %d  %d \n", puissance, puissances[puissance]);
        fileWriteData(fileHandle, puis, strlen(puis));

        // Application de la puissance au moteur et attente de stabilisation (100 ms)
        setMotorSpeed(motorA, puissance * sens);
        delay(100);
        puissance += 1;

        if (puissance >= 100) { active = 1; }
    }

    // Arrêt du moteur, fermeture propre du fichier et arrêt des tâches
    setMotorSpeed(motorA, 0);
    fileClose(fileHandle);
    stopAllTasks();
}

task main()
{
    motorCharacterization();
}